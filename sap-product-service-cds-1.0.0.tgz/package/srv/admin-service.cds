using { sap.capire.products as Database } from '../db/schema';

service AdminService{

entity ProductsSrv as projection on Database.Products;
entity CategoriesSrv as projection on Database.Categories;

}
